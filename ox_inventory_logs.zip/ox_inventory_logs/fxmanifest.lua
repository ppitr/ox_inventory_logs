fx_version 'cerulean'
game 'gta5'
author 'pitr'
description 'discord logs for ox_inventory'

server_scripts {
    'configs/sv_logs.lua',
    'server/sv_oxhook.lua',
    'server/sv_hooks.lua'
}
